var express = require('express');
const mongodb = require('mongodb');
const mongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017/clinicManagement';
var router = express.Router();

const client = new mongoClient(url, { useUnifiedTopology: true });
client.connect();

router.get('/doctors', function(req, res, next) {
  res.render('doctors');
})

router.get('/createcollectionD', async (req, res) => {
  var msg = '';
  await client.db().listCollections({name: 'doctors'}).next(async function(err, collinfo) { 
    if (err) throw err;
      if (collinfo) { //Validates if the collection already exists
        console.log('Collection already exist');
        msg = 'Collection already exist';
        res.end(msg);
      }
      else{
        await client.db().createCollection('doctors', async (err, result) => {
          if (err) throw err;
          msg = 'Collection successfully created';
          res.end(msg);
        });
      }
  });
});

router.post('/insertoneD', async (req, res) => {
  let form = req.body;
  await client.db().collection('doctors').insertOne(form, (err, result) => {
    if (err) throw err;
    res.end();
  });
});

router.get('/findallD', async (req, res) => {
  await client.db().collection('doctors').find().toArray((err, result) => {
    if (err) throw err;
    res.send(JSON.stringify(result));
    res.end();
  });
});

router.get('/search/:param', async (req, res) => {
  let param = req.params.param;
  let query = {$or:[
    {fname: new RegExp(param, 'i')},
    {lname: new RegExp(param, 'i')}
  ]}; //Searches by fullname, case insensitive
  await client.db().collection('doctors').find(query).toArray((err, result) => {
    if (err) throw err;
    res.send(JSON.stringify(result));
    res.end();
  });
});

router.delete('/deleteoneD/:id', async (req, res) => {
  let id = req.params.id;
  let query = {_id: new mongodb.ObjectId(id)}; 
  await client.db().collection('doctors').deleteOne(query, (err, result) => {
    if (err) throw err;
    res.end();
  });
});

router.delete('/deleteallD', async (req, res) => {
  await client.db().collection('doctors').deleteMany({}, (err, result) => {
    if (err) throw err;
    res.end();
  });
});

router.put('/updaterecordD/:updateid', async (req, res)  => {
  let updateid = req.params.updateid;
  let form = req.body;
  let query = {_id: new mongodb.ObjectId(updateid)};
  let newValues = {$set: form};
  await client.db().collection('doctors').updateOne(query, newValues, (err, result) => {
    if (err) throw err;
    res.end();
  });
});

module.exports = router;
