var express = require('express');
const mongodb = require('mongodb');
const mongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017/clinicManagement';
var router = express.Router();


const client = new mongoClient(url, { useUnifiedTopology: true });
client.connect();

router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/createcollection', async (req, res) => {
  var msg = '';
  await client.db().listCollections({name: 'users'}).next(async function(err, collinfo) { 
    if (err) throw err;
      if (collinfo) { //Validates if the collection already exists
        console.log('Collection already exist');
        msg = 'Collection already exist';
        res.end(msg);
      }
      else{
        await client.db().createCollection('users', async (err, result) => {
          if (err) throw err;
          msg = 'Collection successfully created';
          res.end(msg);
        });
      }
  });
});

router.post('/registerUser', async (req, res) => {
  let form = req.body;
  await client.db().collection('users').insertOne(form, (err, result) => {
    if (err) throw err;
    res.end();
  });
});

module.exports = router;
