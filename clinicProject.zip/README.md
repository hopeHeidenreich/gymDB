# mongodb-express-example
This project uses Vue JS library in the frontend and Express in the backend

# To run the project, execute: 
npm install
npm run start
