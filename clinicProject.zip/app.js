var express = require('express');
var http = require('http');
var path = require('path');
var logger = require('morgan');
var cookieParser = require('cookie-parser');

var app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use(require('./routes/index'));
app.use(require('./routes/doctors'));
app.use(require('./routes/login'));
app.use(require('./routes/passwords'));
app.use(require('./routes/patients'));
app.use(require('./routes/appointments'));

// Showing patients page
//app.get("/patients", function (req, res) {
//    res.render("patients");
//});
//
//// Showing doctors page
//app.get("/doctors", function (req, res) {
//    res.render("doctors");
//});
//
//// Showing appointments page
//app.get("/appointments", function (req, res) {
//    res.render("appointments");
//});
//
//// Showing passwords page
//app.get("/passwords", function (req, res) {
//    res.render("passwords");
//});
//  
//// Showing register form
//app.get("/", function (req, res) {
//    res.render("index");
//});
//  
//// Handling user signup
//app.post("/registerUser", async (req, res) => {
//    const user = await User.create({
//      email: req.body.email,
//      pass: req.body.pass
//    });
//    
//    return res.status(200).json(user);
//  });
//  
////Showing login form
//app.get("/login", function (req, res) {
//    res.render("login");
//});
//  
////Handling user login
//app.post("/loginUser", async function(req, res){
//    try {
//        // check if the user exists
//        const user = await User.findOne({ email: req.body.email });
//        if (user) {
//          //check if password matches
//          const result = req.body.pass === user.pass;
//          if (result) {
//            res.render("secret");
//          } else {
//            res.status(400).json({ error: "password doesn't match" });
//          }
//        } else {
//          res.status(400).json({ error: "User doesn't exist" });
//        }
//      } catch (error) {
//        res.status(400).json({ error });
//      }
//});
//  
////Handling user logout 
//app.get("/logout", function (req, res) {
//    req.logout(function(err) {
//        if (err) { return next(err); }
//        res.redirect('/');
//      });
//});
//  
//  
//  
//function isLoggedIn(req, res, next) {
//    if (req.isAuthenticated()) return next();
//    res.redirect("/login");
//}

var port = process.env.PORT || '3000';
app.set('port', port);
var server = http.createServer(app);
server.listen(port);

console.log('Server listening on port: ' + port);
console.log(`Click the following link to run the server: http://localhost:${port}`);



module.exports = app;
